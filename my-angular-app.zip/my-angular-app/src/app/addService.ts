import { ExpressionType } from "@angular/compiler";
import { Injectable} from "@angular/core";

@Injectable({
    providedIn:'root'
})

export class addService{

    private items: string[] = [];

    addItem(item: string): void {
      this.items.push(item);
    }
  
    getItems(): string[] {
      return this.items;
    }
    
}